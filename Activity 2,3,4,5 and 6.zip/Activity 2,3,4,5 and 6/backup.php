<?php
session_start();

$username = "root";
$password = "";
$host = "localhost";
$databasename = "test";
$path = "C:/xampp/htdocs/Activity4withEventLog/sql/aaaa.sql";
$backup = exec('/xampp/mysql/bin/mysqldump --user=' .$username.' --password=' .$password. ' --host='.$host.' '.$databasename. ' > '. $path. '');

if(isset($_POST['backup'])){
    if(file_exists($path)){
      
      echo '<script>alert("BACKUP SUCCESS")</script>';
      echo"<br>";
    }
    else{
        echo '<script>alert("BACKUP FAILED")</script>';
        echo"<br>";
        echo"Backup of ".$databasename." does not exist in".$path;
    }
}

if(isset($_POST['download'])){
    if(file_exists($path)){
        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('COntent-Disposition: attachment; filename="'. basename($path).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }
    else{
        echo "File does not exist!";
    }
}

if (!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true) {
    header("location: forgot.php");
    exit;
}
if (isset($_POST['reset'])) {
    $getid = $_POST['getid'];
    $_SESSION["getid"] = $getid;
    $getusername = $_POST['getusername'];
    $_SESSION["getusername"] = $getusername;

    header("location: forgot.php");
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    
    <title>Welcome</title>
</head>
<style>
        body {
    margin: 0;
    padding: 0;
    font-family: "Montserrat", Arial, sans-serif;
    background: #2691d9;
    background-attachment: fixed;
    background-repeat: no-repeat;
    background-size: cover;
    height: 100vh;
    overflow: hidden;
    }

       form{
        margin-top: 20%;
        margin-left: auto;
        font-size: 20pt;
        color: white;

       }
       input[type = "submit"] {
    width: 200px;
    height: 50px;
    border: 1px solid;
    background: #2691d9;
    border-radius: 25px;
    font-size: 18px;
    color: #e9f4fb;
    font-weight: 700;
    cursor: pointer;
    outline: none;
  }

input[type = "submit"]:hover {
    opacity: .7;
	cursor: pointer;
}

button {
        width: 200px;
    height: 50px;
    border: 1px solid;
    background: #2691d9;
    border-radius: 25px;
    font-size: 18px;
    color: #e9f4fb;
    font-weight: 700;
    cursor: pointer;
    outline: none;

  }

button:hover {
    opacity: .7;
	cursor: pointer;
}

</style>
<body>
   
     <form class="form-group" method="post">
     <center>
        <input type="radio" class="form-group" name="download">
        <label for="Download"> Download </label><br>
        <label><input type="radio" class="form-group" name="backup">
        <label for="Backup"> Backup </label><br><br>
        <br>
        <input type="submit" class="form-group" value="Mysql Backup"> <br> <br>
        <button type="button" class="btn" name="register" onclick="window.location.href='../Activity4withEventLog/main.php'">BACK</button>
        <br><br><br>
        </center>
    </form>
    
        
</body>

</html>