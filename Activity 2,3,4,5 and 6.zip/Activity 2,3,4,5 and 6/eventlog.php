<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Eventlog</title>
    <style>

        body {
    margin: 0;
    padding: 0;
    font-family: "Montserrat", Arial, sans-serif;
    background: #2691d9;
    background-attachment: fixed;
    background-repeat: no-repeat;
    background-size: cover;
    height: 100vh;
    overflow: hidden;
}
    
    button {
        width: 200px;
    height: 50px;
    border: 1px solid;
    background: #2691d9;
    border-radius: 25px;
    font-size: 18px;
    color: #e9f4fb;
    font-weight: 700;
    cursor: pointer;
    outline: none;

  }

button:hover {
    opacity: .7;
	cursor: pointer;
}

        th{
            height: 100px;
            color: #fff;

        }
        td{
            text-align:center;
            color:white;
            width:300px;
            height:50px;
        }

        h1 {
    text-align: center;
    padding: 0 0 20px 0;
    font-family: "Montserrat";
    color: #fff;
}

    </style>
</head>
<body>
<br>
<div class="container">
            <center>
            <br>
            <button type="button" class="btn" name="register" onclick="window.location.href='../Activity4withEventLog/main.php'">BACK</button>

                <br><br>

                
            </center>
</div>
</body>
 <br>
<center>
<?php
    require_once "config.php";

    $result = mysqli_query($con,"SELECT * FROM userlog");

    echo "<center><table border='1'>
    <tr>
    
    <th>Username</th>
    <th>Activity</th>
    <th>Date & Time</th>

    </tr>";

    while($row = mysqli_fetch_array($result))
    {
        echo "<tr>";
        echo "<td>" . $row['username'] . "</td>";
        echo "<td>" . $row['activity'] . "</td>";
        echo "<td>" . $row['dateandtime'] . "</td>";
        echo "</tr>";
    }
    echo "</table></center>";

    mysqli_close($con);
?>

<br> <br>
</html>