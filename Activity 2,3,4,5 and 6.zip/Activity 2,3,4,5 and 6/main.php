<?php 

?>
 
<!DOCTYPE html>
<html>

<head>
<title>Main Page</title>
<link rel="stylesheet" href="style.css" />
</head>
<style>

  
  .card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  max-width: 500px;
  height: 550px;
  margin: auto;
  text-align: center;
}


</style>
<body>

<form method="post">

<div class = "center">


<h1>Welcome!</h1>
    
    <center>
        <button type="submit" class="btn" method="post" name="UserView" id="logout">User View</button>
    	<br>
        <button type="submit" class="btn" method="post" name="BackupDB" id="logout">Back Up Database</button><br>
        <button type="submit" class="btn" method="post" name="EventLog" id="logout">Eventlog</button><br>
        <button type="submit" class="btn" method="post" name="logout" id="logout">Logout</button><br>
        <br>
        
    </center>

</form>
</div>
</body>

<?php
session_start();

  include 'config.php';

  $_SESSION["verify"] = false;
  $_SESSION["code_access"] = false;

  if (isset($_REQUEST['logout'])){

        date_default_timezone_set('Asia/Manila');
        $currentDate = date('Y-m-d H:i:s');
        $currentDate_timestamp = strtotime($currentDate);
        $_SESSION["current"] = $currentDate;

        $_SESSION["verify"] = true;
        $_SESSION["code_access"] = true;

        $id = $_SESSION["id"];
        $username = $_SESSION["username"];

        $sql = "INSERT INTO `userlog` (user_id, username, activity, dateandtime) VALUES ('$id', '$username', 'Logged Out', '$currentDate')";
            $result = mysqli_query($con, $sql);
      
        if($result){
            header("Location: ../Activity4withEventLog/index.php");
        }else{

        }      
  } 
  if(isset($_REQUEST['UserView'])){
            header("Location: ../Activity4withEventLog/userview.php");

        }
    if (isset($_REQUEST['BackupDB'])){
            header("Location: ../Activity4withEventLog/backup.php");

        }
        if (isset($_REQUEST['EventLog'])){
            header("Location: ../Activity4withEventLog/eventlog.php");

        }
  

      
?>

</html>
