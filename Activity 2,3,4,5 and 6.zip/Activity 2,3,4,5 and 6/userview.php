<?php
	function fetch_data(){
		$output = '';
		$conn = mysqli_connect("localhost", "root", "", "aaaa");
		$sql = "SELECT * FROM users";
		$result=mysqli_query($conn,$sql);

		while($row = mysqli_fetch_array($result)){
			$output .= '<tr>
							<td>' . $row["id"].'</td>
							<td>' . $row["name"].'</td>
							<td>' . $row["email"].'</td>
							
						</tr>';
		}
		return $output;
	}

	if(isset($_POST["generate_pdf"])){
		require_once('TCPDF/tcpdf.php');

		$obj_pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);
		$obj_pdf->SetCreator(PDF_CREATOR);
		$obj_pdf->SetTitle('Users');
		$obj_pdf->SetHeaderData('','', PDF_HEADER_TITLE, PDF_HEADER_STRING);
        $obj_pdf->SetHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
        $obj_pdf->SetFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

        $obj_pdf->SetDefaultMonospacedFont('courier');
        $obj_pdf->SetMargins(PDF_MARGIN_LEFT, '5', PDF_MARGIN_RIGHT);
        $obj_pdf->SetPrintHeader(false);
        $obj_pdf->SetPrintFooter(false); 

        $obj_pdf->SetAutoPageBreak(TRUE, 10);
        $obj_pdf->SetFont('courier', '', 11.5);
        $obj_pdf->AddPage();

        $content='';
        $content.='
        	<h4 align="center"> Generate TABLE DATA to PDF From MySQL Database Using TCPDF in PHP </h4><br/>
        	<table border="1" cellspacing="0" cellpadding="3">
        	<tr>
        		<th width="9%"> ID </th>
        		<th width="38%"> USERNAME </th>
        		<th width="38%"> EMAIL ADDRESS </th>
        		
        	</tr>
        ';
        $content .= fetch_data();
        $content .= '</table>';
        $obj_pdf->writeHTML($content);
        $obj_pdf->Output('Users.pdf', 'D');

	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Lab Activity - Users View</title> 

    <meta charset="UTF-8">
    <meta name="viewport" content="width-device-width, initial-scale=1">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <style>

body {
    margin: 0;
    padding: 0;
    font-family: "Montserrat", Arial, sans-serif;
    background: #2691d9;
    background-attachment: fixed;
    background-repeat: no-repeat;
    background-size: cover;
    height: 100vh;
    overflow: hidden;
}
    
    button {
        width: 200px;
    height: 50px;
    border: 1px solid;
    background: #2691d9;
    border-radius: 25px;
    font-size: 18px;
    color: #e9f4fb;
    font-weight: 700;
    cursor: pointer;
    outline: none;

  }

button:hover {
    opacity: .7;
	cursor: pointer;
}

        th{
            height: 100px;
            color: #fff;

        }
        td{
            text-align:center;
            color:white;
            width:300px;
            height:50px;
        }

        h1 {
    text-align: center;
    padding: 0 0 20px 0;
    font-family: "Montserrat";
    color: #fff;
}

    </style>
</head>  
<body>
                
    <div class="wrapper">
        <h1> USERS </h1>
        <form action="" method="post" name="login"><br>
        
<center>

<?php
    require_once "config.php";

    $result = mysqli_query($con,"SELECT * FROM users");

    echo "<table border='1'>
    <tr>
    <th>User ID</th>
    <th>Full Name</th>
    <th>Email Address</th>
    </tr>";

    while($row = mysqli_fetch_array($result))
    {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . $row['name'] . "</td>";
        echo "<td>" . $row['email'] . "</td>";
        echo "</tr>";
    }
    echo "</table>";

    mysqli_close($con);
?>

</center> <br> <br>

<div class="container">
            <center>
                <button Type="submit" Name="generate_pdf" class="btn" >Generate PDF</button>
                <button type="button" class="btn" name="register" onclick="window.location.href='../Activity4withEventLog/main.php'">BACK</button>

                <br><br>

                
            </center>
        </div>
    </div>

</body>
</html>